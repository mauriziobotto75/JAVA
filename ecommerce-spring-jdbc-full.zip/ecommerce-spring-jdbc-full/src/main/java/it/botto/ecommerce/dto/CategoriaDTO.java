
package it.botto.ecommerce.dto;
import jakarta.validation.constraints.*;
public class CategoriaDTO {
 private Long id;
 @NotBlank @Size(min=2,max=100) private String nome;
 @Size(max=255) private String descrizione;
 public Long getId(){return id;} public void setId(Long id){this.id=id;}
 public String getNome(){return nome;} public void setNome(String nome){this.nome=nome;}
 public String getDescrizione(){return descrizione;} public void setDescrizione(String descrizione){this.descrizione=descrizione;}
}
