
package it.botto.ecommerce.domain;
public class Prodotto {
 private Long id; private String nome; private String descrizione; private Double prezzo; private Long idCategoria;
 public Long getId(){return id;} public void setId(Long id){this.id=id;}
 public String getNome(){return nome;} public void setNome(String nome){this.nome=nome;}
 public String getDescrizione(){return descrizione;} public void setDescrizione(String descrizione){this.descrizione=descrizione;}
 public Double getPrezzo(){return prezzo;} public void setPrezzo(Double prezzo){this.prezzo=prezzo;}
 public Long getIdCategoria(){return idCategoria;} public void setIdCategoria(Long idCategoria){this.idCategoria=idCategoria;}
}
